$(document).ready(function () {
  $("#header-host").load("../components/header.html");
  $("#footer-host").load("../components/footer.html");
  $("#sobre-host").load("../pages/sobre.html");
  $("#nossos-produtos-host").load("../pages/nossos-produtos.html");
  $("#comentarios-clientes-host").load("../pages/comentarios-clientes.html");
  $("#nossos-precos-host").load("../pages/nossos-precos.html");
});
