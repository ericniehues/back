# PROJETO WEB-HOSTING

## Programação V

- Layout do site para se basear: https://1.envato.market/c/1297116/475676/4415?u=http://preview.themeforest.net/item/material-hosting-wordpress-theme-whmcs/full_screen_preview/18147644

- Como fazer os componentes da pagina: https://materializecss.com/about.html

## Como rodar o site?

- Nas extensões do VSCode procure por Live Server e instale
- Depois de instalado no canto direito em baixo vai ter "Go Live", clicando ali já deve abrir a página so site
- Caso não tenha sucesso da primeira forma, aperte "Ctrl + Shift + P"
- Digite "live server", selecione a opção "Abir com Live Servier" ("Open with live server").
- O site normalmente fica disponível em: http://127.0.0.1:5500/
